import { FilterTodos } from './../.nuxt/components.d';
import { defineStore } from "pinia"

//  import axios from "axios";
//  import { useStore } from "~/stores/myStore";

// const state = {
//   todos: [],
// };

// const getters = {
//   allTodos: (state) => state.todos,
// };

// const actions = {
//   async fetchTodos({ commit }) {
//     // const response = await axios.get(
//       "https://jsonplaceholder.typicode.com/todos"
//     );

//     commit("setTodos", response.data);
//   },
//   async addTodo({ commit }, title) {
//     const response = await axios.post(
//       "https://jsonplaceholder.typicode.com/todos",
//       { title, completed: false }
//     );

//     commit("newTodo", response.data);
//   },
//   async deleteTodo({ commit }, id) {
//     await axios.delete(`https://jsonplaceholder.typicode.com/todos/${id}`);

//     commit("removeTodo", id);
//   },
//   async filterTodos({ commit }, e) {
//     // Get selected number
//     const limit = parseInt(
//       e.target.options[e.target.options.selectedIndex].innerText
//     );

//     const response = await axios.get(
//       `https://jsonplaceholder.typicode.com/todos?_limit=${limit}`
//     );

//     commit("setTodos", response.data);
//   },
//   async updateTodo({ commit }, updTodo) {
//     const response = await axios.put(
//       `https://jsonplaceholder.typicode.com/todos/${updTodo.id}`,
//       updTodo
//     );

//     console.log(response.data);

//     commit("updateTodo", response.data);
//   },
// };

// const mutations = {
//   setTodos: (state, todos) => (state.todos = todos),
//   newTodo: (state, todo) => state.todos.unshift(todo),
//   removeTodo: (state, id) =>
//     (state.todos = state.todos.filter((todo) => todo.id !== id)),
//   updateTodo: (state, updTodo) => {
//     const index = state.todos.findIndex((todo) => todo.id === updTodo.id);
//     if (index !== -1) {
//       state.todos.splice(index, 1, updTodo);
//     }
//   },
// };

// export default {
  
//   state,
//   getters,
//   actions,
//   mutations,
// };
// import { createPinia } from "pinia";


// const pinia = createPinia();

// export default pinia;
// import { defineStore } from "pinia";
import { AddTodo } from "~~/.nuxt/components";
import { TodoItem } from "~~/types/todo";

// export const useTodoStore = 
// defineStore('todos', {
//     state: () => ({
//         todoList: []
//     }),
//     getters: {
//         allTodos:(state) => state.todoList
//     },
//     actions: {
//         async fetchTodos() {
//           const res = await fetch('https://jsonplaceholder.typicode.com/todos')
//           const data = await res.json()
//           this.allTodos.push(...data)
//           console.log(this.allTodos);
//           },
//     }
// })
export const useTodoStore = defineStore('todos', {
  state: () => ({todos: [] as TodoItem[]}),

  actions: {
    async fetchTodos() {
    const response = await $fetch<TodoItem[]>(
      'https://jsonplaceholder.typicode.com/todos'
    )

    this.todos = response;
    },
   async filterTodos(e: any) {
    const limit = parseInt(
      e.target.options[e.target.options.selectedIndex].innerText
    );
    const response = await $fetch(
      `https://jsonplaceholder.typicode.com/todos?_limit=${limit}`
    );
    this.todos= response;
   },
   async updateTodo(updateTodo) {
    const response = await $fetch<TodoItem[]> (
      `https://jsonplaceholder.typicode.com/todos/${updateTodo.id}`,
      {
        method: "PUT", body: {
          title:updateTodo.title,
          completed:updateTodo.completed
        }
      }
    )
    var index = this.todos.findIndex(todo => todo.id === updateTodo.id) 
    if(index !== -1){
      this.todos.splice(index,1,updateTodo)
    }
   },
    async addTodo(title: string) {
      // console.log("adding")
      const response = await $fetch<TodoItem> (
        "https://jsonplaceholder.typicode.com/todos",{
        method: "POST",
        body:{
          title:title,
          // body:"",
          
        },
      })
      this.todos.unshift(response);
    },
    async deleteTodo(id:number) {
      const response = await $fetch<TodoItem>
      ('https://jsonplaceholder.typicode.com/posts/1', {
        method: 'DELETE',
});
   this.todos = this.todos.filter(todo => todo.id !== id)
    },
   
  }
})