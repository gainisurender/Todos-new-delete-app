export interface TodoItem{
    json(): any;
    userId:number;
    id:number;
    title:string;
    isCompleted:boolean;
    
}